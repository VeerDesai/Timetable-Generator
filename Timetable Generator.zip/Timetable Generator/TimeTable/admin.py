from django.contrib import admin
from.models import *


admin.site.register(Teacher)
admin.site.register(Time)
admin.site.register(Courses)
admin.site.register(Semester)
