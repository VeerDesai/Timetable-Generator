from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.contrib.auth.models import AbstractUser
from django.db.models.signals import post_save, post_delete

class Teacher(models.Model):
    
    name = models.CharField(max_length=25)
    semester=models.IntegerField(default=0,verbose_name='class')
    subject=models.CharField(max_length=25)
    subject_count=models.IntegerField(default=0)
    dayhrs=models.IntegerField(default=0)
  
    def __str__(self):
        return f'{self.name}'
        
class Time(models.Model):
    
    
    day=models.IntegerField(default=0)
    period=models.IntegerField(default=0)
    
    
    def __str__(self):
        return f'{self.day}'
                
class Semester(models.Model):
    
    
    semesters=models.IntegerField(default=0,verbose_name='classes')
    
    
    def __str__(self):
        return f'{self.semesters}'
        
class Courses(models.Model):
    
    name = models.CharField(max_length=25,primary_key=True, serialize=False)
    lectures=models.IntegerField(default=0,verbose_name="credit_hrs")
    
    
    def __str__(self):
        return f'{self.name}'
                        
                
