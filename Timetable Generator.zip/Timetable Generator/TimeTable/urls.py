from django.contrib import admin
from django.urls import path, include
from. import views

urlpatterns = [
    path('', views.home, name='home'),
    path('timetable_generation/', views.timetable, name='timetable'),
    
    path('add_instructor/', views.add_instructor, name='addinstructor'),
    path('instructor_list/', views.inst_list_view, name='editinstructor'),
    path('delete_instructor/<int:pk>/', views.delete_instructor, name='deleteinstructor'),
    
    path('add_course/', views.add_course, name='addcourse'),
    path('course_list/', views.course_list_view, name='editcourse'),
    path('delete_course/<str:pk>/', views.delete_course, name='deletecourse'),
    
    path('add_department/', views.add_department, name='adddepartment'),
    path('department_list/', views.department_list, name='editdepartment'),
    path('delete_department/<int:pk>/', views.delete_department, name='deletedepartment'),
    
    path('add_Time/', views.add_Time, name='addtime'),
    path('Time_list/', views.Time_list, name='edittime'),
    path('delete_time/<int:pk>/', views.delete_time, name='deletetime'),
]
