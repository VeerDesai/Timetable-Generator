from django.forms import ModelForm
from. models import *
from django import forms


class TeacherForm(ModelForm):
    class Meta:
        model = Teacher
        fields = [
            
            'name',
           
            'subject',
            'semester',
            'subject_count',
            'dayhrs',
            
            
        ]


class TimeForm(ModelForm):
    class Meta:
        model =Time
        fields = [
            'day',
            'period',
            
            
        ]
        

class CourseForm(ModelForm):
    class Meta:
        model = Courses
        fields = ['name','lectures']


class SemesterForm(ModelForm):
    class Meta:
        model = Semester
        fields = ['semesters']



