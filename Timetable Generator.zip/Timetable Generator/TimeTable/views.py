from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import *
from. forms import *

# period values from data base
period = {
          "d": 5,
          "p": 4,
         }
v=[]

def changetime():
    ts=Time.objects.all()
    for tm in ts:
        period.update({"d":tm.day})
        period.update({"p":tm.period})
        
    v.clear()
    for i in range(period["p"]):
        v.append(i+1)
   
    
      
    




count=0
## semesters values from database:
c=[]
def changeclasses():
    c.clear()
    cs =Semester.objects.all()
    val=0
    for item in cs:
        val=item.semesters
        break
    ch='a'
    for i in range(val):
        c.append(ch)
        ch=ch+'a'
       
    
   
    
   
    

s = []

def changecourses():
    s.clear()
    crs =Courses.objects.all()
    
    for item in crs:
        s.append({"name":item.name,"creditHr":item.lectures})
        
    
       
        
t=[]    
def changeteacher():
    t.clear()
    tch=Teacher.objects.all() 
    
    
    for item in tch:
    
        t.append({"name":item.name, "assigned":[{"CLASS":c[item.semester-1],"subject":item.subject,"count":item.subject_count,"hrs":item.dayhrs,}]})
   
    cout=len(t)
    z=0
    while z < len(t):
        var=t[z]["name"]
        i=0
        while i < len(t):
            val=t[i]["assigned"][0]["count"]
            if t[i]["name"]==var and val>1:
                t[z]["assigned"].append({"CLASS":t[i]["assigned"][0]["CLASS"],"subject":t[i]["assigned"][0]["subject"],"count":t[i]["assigned"][0]["count"],"hrs":t[i]["assigned"][0]["hrs"],})
                
                
                del t[i]
                i-=1
           
            i+=1
       
        z+=1
   
        
        
    
def isSchedulePossible(tIndex, cn, period,t_available,c_available):
    if (t_available[tIndex][period["d"]][period["p"]] or c_available[cn][period["d"]][period["p"]])!=True:
        return True
    else: return False   
    
def ThreeDarray(x, y, z):
    array = []



    for i in range(x):

        array.append([])

   
        for j in range(y):

            array[i].append([])



            for k in range(z):

                array[i][j].append(0)

    
    
  
    return array    
       
    






    
def find(dicts, key, value):
    class Null: pass
    for i, d in enumerate(dicts):
        if d.get(key, Null) == value:
            return i
    else:
        return -1
vas=[]
def check(cn,teacher,day,per,t_available):
    
    vas.clear()
    r=cn
    
    while(r>0):
        
        vas.extend([some(t_available[teacher][day][per],c[r-1])])
        r-=1
        if any(vas):
            break
      
    return vas

def some(arr, value):
    if arr ==value :
        return 1
            
    else:
        return 0        


 





remainingLectures=[]

           

def Scheduling():
    t_available = ThreeDarray(len(t), period["d"], period["p"])
    c_available = ThreeDarray(len(c), period["d"], period["p"])

    

        
    remainingLectures.clear()
    for i in range(len(c)):
        remainingLectures.append([]) 
        val2=0
        for j in range(len(t)):
            remainingLectures[i].append(0)
            valid = find(t[j]["assigned"],"CLASS",c[i])
            if valid!=-1:
                val=t[j]["assigned"][valid]["subject"]
                for item in s:
                    if item["name"]==val:
                        val2=item["creditHr"]
                remainingLectures[i][j] =val2    
                 
            else:
                remainingLectures[i][j] =0
    final_tt = ThreeDarray(len(c), period["d"], period["p"])
    for i in range(len(c)):
        for j in range(len(t)):
            print(f"{remainingLectures[i][j]:<2}", end="") 
        print("\n")   
    for per in range(period["p"]): 
        for day in range(period["d"]):
            for cn in range(0,len(c)):
                if final_tt[cn][day][per] == 0:
                    for teacher in range(len(t)):
                        valid = find(t[teacher]["assigned"],"CLASS",c[cn])

                        val=check(cn,teacher,day,per,t_available)

                        if valid ==-1  or any(val) or remainingLectures[cn][teacher] ==0: 
                            continue
            
                        if (isSchedulePossible(teacher, cn, { "d": day, "p": per },t_available,c_available)) :
                            lectureCount = 1
                            longestLecture = t[teacher]["assigned"][valid]["hrs"]
                          
            
                            if remainingLectures[cn][teacher]>1 and longestLecture >1  and isSchedulePossible(teacher, cn, { "d": day, "p": per+1 },t_available,c_available): 
                                lectureCount = 2

                                if longestLecture > 2 and isSchedulePossible(teacher, cn, { "d": day, "p": per+2 },t_available,c_available):
                                    lectureCount = 3
                        
                            for i in range(0,lectureCount):
                                final_tt[cn][day][per + i] = t[teacher]["assigned"][valid]["subject"]
                                c_available[cn][day][per + i] = t[teacher]["name"]
                                t_available[teacher][day][per + i] = c[cn];
                                remainingLectures[cn][teacher]-=1
              
                            break
            
    return final_tt

   



def home(request):
    return render(request, 'index.html')

def timetable(request):
    changetime()
    changeclasses()
    changecourses()
    changeteacher()
    final=Scheduling();

    for cindex in range(len(c)):
        print("\n""CLASS",cindex+1)
        for i in range(period["d"]):
            for j in range(period["p"]):
              print(f"{final[cindex][i][j]:<20}", end="")
              
            print()
     
        print("\n\n")     
    

    for i in range(len(c)):
        for j in range(len(t)):
            print(f"{remainingLectures[i][j]:<2}", end="") 
        print("\n") 
    return render(request, 'timetable.html', {'schedule': final,'count':count,'per':v})

def add_instructor(request):
    form = TeacherForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('addinstructor')
    context = {
        'form': form
    }
    return render(request, 'adins.html', context)
    
def inst_list_view(request):
    context = {
        'instructors': Teacher.objects.all()
    }
    return render(request, 'instlist.html', context)


def delete_instructor(request, pk):
    inst = Teacher.objects.filter(pk=pk)
    if request.method == 'POST':
        inst.delete()
        return redirect('editinstructor')
    




def add_course(request):
    form = CourseForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('addcourse')
        else:
            print('Invalid')
    context = {
        'form': form
    }
    return render(request, 'adcrs.html', context)
    
    
def course_list_view(request):
    context = {
        'courses': Courses.objects.all()
    }
    return render(request, 'crslist.html', context)
    
def delete_course(request, pk):
    crs = Courses.objects.filter(pk=pk)
    if request.method == 'POST':
        crs.delete()
        return redirect('editcourse')



def add_department(request):
    form = SemesterForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('adddepartment')
    context = {
        'form': form
    }
    return render(request, 'addep.html', context)

   
def department_list(request):
    context = {
        'semester': Semester.objects.all()
    }
    return render(request, 'deptlist.html', context)


def delete_department(request, pk):
    semester = Semester.objects.filter(pk=pk)
    if request.method == 'POST':
        semester.delete()
        return redirect('editdepartment')

def add_Time(request):
    form = TimeForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            
            return redirect('addtime')
    context = {
        'form': form
    }
    return render(request, 'addtime.html', context)

   
def Time_list(request):
    context = {
        'time': Time.objects.all()
    }
    return render(request, 'Timelist.html', context)


def delete_time(request, pk):
    
    
    semester = Time.objects.filter(pk=pk)
    if request.method == 'POST':
        
        semester.delete()
        return redirect('edittime')





    


  



