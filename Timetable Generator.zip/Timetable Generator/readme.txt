TO RUN THE APP 
 FIRST INSTALL DJANGO 

 sudo pip3 install Django

 THEN  in terminal go to Scheduler Directory

 cd Sheduler

 python3 manage.py runserver

 then in your browser in adress bar type

 localhost:8000

 note: use firefox browser

